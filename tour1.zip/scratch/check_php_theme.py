import os

php_files = [f for f in os.listdir('.') if f.endswith('.php')]
for pf in php_files:
    with open(pf, 'r', encoding='utf-8', errors='ignore') as f:
        content = f.read()
    if 'style.css' in content:
        has_theme = 'theme-custom.css' in content
        print(f"File '{pf}' loads style.css: has_theme_custom={has_theme}")
