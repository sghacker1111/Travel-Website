import requests
import json
import os

base_url = 'http://127.0.0.1:8080'
theme_path = 'data/theme.json'
css_path = 'assets/css/theme-custom.css'

print("--- STARTING ADVANCED THEME CUSTOMIZER TESTS ---")

# Step 1: Backup current theme state
print("\n[1] Backing up current theme settings...")
original_theme = None
if os.path.exists(theme_path):
    with open(theme_path, 'r', encoding='utf-8') as f:
        original_theme = json.load(f)
    print("[+] Theme settings backed up.")
else:
    print("[!] No original theme settings found. Will reset to defaults at the end.")

# Step 2: Login as admin
print("\n[2] Logging in as admin...")
session = requests.Session()
login_data = {
    'login_submit': '1',
    'username': 'admin',
    'password': 'Top@#sg@#mountain'
}
r = session.post(f"{base_url}/admin", data=login_data)
if "logout" not in r.text.lower() and "dashboard" not in r.text.lower():
    print("[-] ERROR: Admin login failed.")
    exit(1)
print("[+] Successfully logged in as admin.")

# Step 3: Post new theme configuration
print("\n[3] Submitting new customizer configuration...")
customizer_data = {
    'theme_submit': '1',
    'primary_color': '#112233',
    'secondary_color': '#445566',
    'accent_color': '#778899',
    'dropdown_icon': 'double_chevron',
    'header_bg': '#aabbcc',
    'header_text': '#ddeeff',
    'title_color': '#ff0011',
    'page_bg': '#ff0022',
    'footer_bg': '#ff0033',
    'footer_text': '#ff0044',
    'menu_bg': '#ffaabb',
    'menu_text_size': '24px',
    'menu_padding': '20px',
    'slider_title_color': '#eeffaa',
    'slider_title_size': '72px',
    'slider_desc_color': '#aaffbb',
    'slider_desc_size': '24px',
    'slider_text_align': 'center'
}

r = session.post(f"{base_url}/admin", data=customizer_data)
if r.status_code != 200:
    print(f"[-] ERROR: Theme submit failed with status {r.status_code}")
    exit(1)
print("[+] Theme submit request completed successfully.")

# Step 4: Verify theme.json contains the settings
print("\n[4] Verifying theme.json database changes...")
with open(theme_path, 'r', encoding='utf-8') as f:
    saved_theme = json.load(f)

expected_keys = [
    'primary', 'secondary', 'accent', 'dropdown_icon', 'header_bg',
    'header_text', 'title_color', 'page_bg', 'footer_bg', 'footer_text',
    'menu_bg', 'menu_text_size', 'menu_padding', 'slider_title_color',
    'slider_title_size', 'slider_desc_color', 'slider_desc_size', 'slider_text_align'
]

for key in expected_keys:
    if key not in saved_theme:
        print(f"[-] ERROR: Key '{key}' not found in theme.json!")
        exit(1)
    
    # Map key names from customizer form to theme.json keys
    form_key = key
    if key == 'primary': form_key = 'primary_color'
    elif key == 'secondary': form_key = 'secondary_color'
    elif key == 'accent': form_key = 'accent_color'
    
    if saved_theme[key] != customizer_data[form_key]:
        print(f"[-] ERROR: Key '{key}' value mismatch. Expected {customizer_data[form_key]}, got {saved_theme[key]}")
        exit(1)

print("[+] Saved settings in theme.json matched the customizer form input.")

# Step 5: Verify theme-custom.css compilation
print("\n[5] Verifying assets/css/theme-custom.css compilation...")
with open(css_path, 'r', encoding='utf-8') as f:
    css_content = f.read()

css_variables = {
    '--color-primary': '#112233',
    '--color-secondary': '#445566',
    '--color-accent': '#778899',
    '--color-header-bg': '#aabbcc',
    '--color-header-text': '#ddeeff',
    '--color-title': '#ff0011',
    '--color-page-bg': '#ff0022',
    '--color-footer-bg': '#ff0033',
    '--color-footer-text': '#ff0044',
    '--color-menu-bg': '#ffaabb',
    '--menu-text-size': '24px',
    '--menu-padding': '20px',
    '--slider-title-color': '#eeffaa',
    '--slider-title-size': '72px',
    '--slider-desc-color': '#aaffbb',
    '--slider-desc-size': '24px',
    '--slider-text-align': 'center'
}

for var_name, expected_value in css_variables.items():
    expected_line = f"{var_name}: {expected_value};"
    if expected_line not in css_content:
        print(f"[-] ERROR: Expected CSS rule '{expected_line}' was not found in theme-custom.css!")
        print(f"CSS File Content:\n{css_content}")
        exit(1)

print("[+] Compiled theme-custom.css values are correct.")

# Step 6: Verify visitor website layout changes
print("\n[6] Verifying changes are visible on the visitor website homepage...")
r = requests.get(base_url)
html = r.text

# Check for position: relative header in header.php styling
if "position: relative" not in html:
    print("[-] ERROR: site-header is not set to relative positioning in header.php HTML.")
    exit(1)
print("[+] Verified header is non-sticky (relative positioning is set).")

# Check for header-bottom-bar wrapper
if "header-bottom-bar" not in html:
    print("[-] ERROR: header-bottom-bar div is not present in visitor homepage HTML.")
    exit(1)
print("[+] Verified full-width header-bottom-bar container wrapper is live.")

# Check for slider layout alignment & typography updates
if "align-items: center" not in html or "text-align: center" not in html:
    print("[-] ERROR: Slider alignment styling (center) not outputted in homepage slide containers.")
    exit(1)
print("[+] Verified homepage slider uses updated alignment rules (center/center).")

if "var(--slider-title-size, 50px) !important" not in html or "var(--slider-title-color, #ffffff)" not in html:
    print("[-] ERROR: Customizer typography variables for slider title size/color are missing from loop slides.")
    exit(1)
print("[+] Verified customizer typography tokens are correctly applied to slider elements.")

# Check for relative package details link and target new tab
if 'href="package.php?slug=' not in html or 'target="_blank"' not in html:
    print("[-] ERROR: Package details link in slider does not use relative package.php?slug= or does not open in a new tab!")
    exit(1)
print("[+] Verified slider details link points to package.php?slug= and opens in a new tab.")

# Step 7: Clean up and restore original settings
print("\n[7] Cleaning up and restoring original settings...")
if original_theme:
    original_post = {
        'theme_submit': '1',
        'primary_color': original_theme.get('primary', '#1e3d2f'),
        'secondary_color': original_theme.get('secondary', '#ff7a00'),
        'accent_color': original_theme.get('accent', '#0077b6'),
        'dropdown_icon': original_theme.get('dropdown_icon', 'triangle'),
        'header_bg': original_theme.get('header_bg', '#ffffff'),
        'header_text': original_theme.get('header_text', '#1f2937'),
        'title_color': original_theme.get('title_color', '#1e3d2f'),
        'page_bg': original_theme.get('page_bg', '#ffffff'),
        'footer_bg': original_theme.get('footer_bg', '#0f172a'),
        'footer_text': original_theme.get('footer_text', '#9ca3af'),
        'menu_bg': original_theme.get('menu_bg', '#ffffff'),
        'menu_text_size': original_theme.get('menu_text_size', '15px'),
        'menu_padding': original_theme.get('menu_padding', '8px'),
        'slider_title_color': original_theme.get('slider_title_color', '#ffffff'),
        'slider_title_size': original_theme.get('slider_title_size', '50px'),
        'slider_desc_color': original_theme.get('slider_desc_color', '#ffffff'),
        'slider_desc_size': original_theme.get('slider_desc_size', '18px'),
        'slider_text_align': original_theme.get('slider_text_align', 'left')
    }
    session.post(f"{base_url}/admin", data=original_post)
    print("[+] Restored original theme settings successfully.")
else:
    # Reset to defaults
    default_post = {
        'theme_submit': '1',
        'primary_color': '#1e3d2f',
        'secondary_color': '#ff7a00',
        'accent_color': '#0077b6',
        'dropdown_icon': 'triangle',
        'header_bg': '#ffffff',
        'header_text': '#1f2937',
        'title_color': '#1e3d2f',
        'page_bg': '#ffffff',
        'footer_bg': '#0f172a',
        'footer_text': '#9ca3af',
        'menu_bg': '#ffffff',
        'menu_text_size': '15px',
        'menu_padding': '8px',
        'slider_title_color': '#ffffff',
        'slider_title_size': '50px',
        'slider_desc_color': '#ffffff',
        'slider_desc_size': '18px',
        'slider_text_align': 'left'
    }
    session.post(f"{base_url}/admin", data=default_post)
    print("[+] Reset to defaults successfully.")

print("\n--- ALL ADVANCED THEME CUSTOMIZER TESTS PASSED SUCCESSFULLY! ---")
