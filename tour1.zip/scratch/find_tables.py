with open('admin.php', 'r', encoding='utf-8') as f:
    content = f.read()

import re
matches = re.finditer(r'<table[^>]*>', content, re.IGNORECASE)
for m in matches:
    line_num = content.count('\n', 0, m.start()) + 1
    print(f"Table start at line {line_num}: {m.group(0)}")

matches_end = re.finditer(r'</table>', content, re.IGNORECASE)
for m in matches_end:
    line_num = content.count('\n', 0, m.start()) + 1
    print(f"Table end at line {line_num}")
