import requests
import json
import re

base_url = 'http://127.0.0.1:8080'

print("--- STARTING THEME RESTRUCTURE VERIFICATION ---")

# 1. Login as Admin
print("\n[1] Authenticating as Admin...")
session = requests.Session()
login_data = {
    'login_submit': '1',
    'username': 'admin',
    'password': 'Top@#sg@#mountain'
}
r = session.post(f"{base_url}/admin", data=login_data)
if r.status_code != 200 or "logout" not in r.text.lower():
    print("[-] ERROR: Admin authentication failed.")
    exit(1)
print("[+] Successfully logged in as admin.")

# 2. Update Theme Customizer Settings via POST
print("\n[2] Applying custom brand configuration in Theme Editor...")
custom_theme = {
    'theme_submit': '1',
    'primary_color': '#2a5e45',       # Custom Forest green
    'secondary_color': '#d97706',     # Custom Amber orange
    'accent_color': '#2563eb',        # Custom Cobalt blue
    'dropdown_icon': 'chevron',       # Custom thin chevron arrow
    'header_bg': '#f8fafc',           # Custom slate header background
    'header_text': '#0f172a',         # Custom dark slate menu text
    'title_color': '#1e40af',         # Custom blue heading title
    'page_bg': '#f1f5f9',             # Custom light gray body background
    'footer_bg': '#1e293b',           # Custom slate footer background
    'footer_text': '#cbd5e1'          # Custom footer link color
}
r = session.post(f"{base_url}/admin", data=custom_theme)
if r.status_code != 200:
    print(f"[-] ERROR: Failed to submit custom brand settings. Status: {r.status_code}")
    exit(1)
print("[+] Custom brand settings successfully saved.")

# 3. Check compilation in theme-custom.css
print("\n[3] Verifying theme-custom.css compiled output...")
r = requests.get(f"{base_url}/assets/css/theme-custom.css")
if r.status_code != 200:
    print("[-] ERROR: Failed to retrieve theme-custom.css.")
    exit(1)

css_content = r.text
required_tokens = [
    '--color-primary: #2a5e45',
    '--color-secondary: #d97706',
    '--color-accent: #2563eb',
    '--color-header-bg: #f8fafc',
    '--color-header-text: #0f172a',
    '--color-title: #1e40af',
    '--color-page-bg: #f1f5f9',
    '--color-footer-bg: #1e293b',
    '--color-footer-text: #cbd5e1'
]
for tok in required_tokens:
    if tok not in css_content:
        print(f"[-] ERROR: Missing CSS token '{tok}' in theme-custom.css.")
        exit(1)
print("[+] Successfully verified compilation of all 9 color properties in theme-custom.css!")

# 4. Check Home Page DOM Layout (Restructured Header)
print("\n[4] Inspecting header structure and dynamic icons on homepage...")
r = requests.get(f"{base_url}/")
html = r.text

if "header-top-row" not in html or "header-bottom-row" not in html:
    print("[-] ERROR: Restructured 2-row header classes (header-top-row / header-bottom-row) not found.")
    exit(1)
print("[+] Restructured two-row header structure verified.")

# Check for dynamic chevron icon presence
if "width=\"10\" height=\"10\" fill=\"currentColor\"" not in html:
    print("[-] ERROR: Dynamic chevron SVG indicator not loaded in menu link.")
    exit(1)
print("[+] Dynamic indicator icon selection ('chevron') successfully rendered.")

# 5. Check Clickable Submenu Titles & Region Pages
print("\n[5] Verifying clickable region submenu headers in mega menu...")
# Search for the href link to everest region trekking
region_link_pattern = r'href="/trekking/everest-region-trekking"'
if not re.search(region_link_pattern, html):
    print("[-] ERROR: Submenu title link '/trekking/everest-region-trekking' not found in navbar markup.")
    exit(1)
print("[+] Clickable sub-menu titles successfully verified in navbar dropdowns.")

# Fetch region page
print("\n[6] Inspecting regional activity archive page details...")
r = requests.get(f"{base_url}/trekking/everest-region-trekking")
region_html = r.text

# Verify package interlinks section exists
if "Explore Regional Expedition Itineraries:" not in region_html:
    print("[-] ERROR: Quick Navigation Index for packages not rendered on region page.")
    exit(1)

# Verify bold orange package links exist on region page
bold_link_pattern = r'href="/trekking/[^"]+"[^>]*style="[^"]*font-weight:\s*800;[^"]*color:\s*var\(--color-secondary\);'
if not re.search(bold_link_pattern, region_html):
    print("[-] ERROR: Correctly styled bold, orange package links not found on region page.")
    exit(1)
print("[+] Package index block with bold, differently colored links is live on region page!")

# 7. Restore Default Theme settings
print("\n[7] Restoring default theme configurations...")
default_theme = {
    'theme_submit': '1',
    'primary_color': '#1e3d2f',
    'secondary_color': '#ff7a00',
    'accent_color': '#0077b6',
    'dropdown_icon': 'triangle',
    'header_bg': '#ffffff',
    'header_text': '#1f2937',
    'title_color': '#1e3d2f',
    'page_bg': '#ffffff',
    'footer_bg': '#0f172a',
    'footer_text': '#9ca3af'
}
session.post(f"{base_url}/admin", data=default_theme)
print("[+] Settings restored to default successfully.")

print("\n--- ALL RESTRUCTURE TESTS PASSED EXQUISITELY! ---")
