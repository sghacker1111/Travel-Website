import os
import re

php_files = []
for root, dirs, files in os.walk('.'):
    if any(p in root for p in ['assets', 'data', '.git', 'scratch']):
        continue
    for file in files:
        if file.endswith('.php'):
            php_files.append(os.path.join(root, file))

for filepath in php_files:
    with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
        content = f.read()
    # Search for links containing activity or activity_id or activity slug
    matches = re.findall(r'href=["\'](?:[^"\']*activity[^"\']*)["\']', content)
    if matches:
        print(f"File '{filepath}' has activity links:")
        for m in matches:
            print(f"  {m}")
