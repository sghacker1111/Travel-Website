with open('package.php', 'r', encoding='utf-8') as f:
    content = f.read()

import re
print("Matches in package.php:")
for match in re.finditer(r'(?i)(see|details|full)', content):
    start = max(0, match.start() - 40)
    end = min(len(content), match.end() + 40)
    print(f"Index {match.start()}: ...{content[start:end].strip()}...")
