with open('admin.php', 'r', encoding='utf-8') as f:
    lines = f.readlines()

start_idx = -1
end_idx = -1
for idx, line in enumerate(lines):
    if 'id="panel-edit"' in line:
        start_idx = idx
    if start_idx != -1 and '<!-- Tab 3:' in line:
        end_idx = idx
        break

if start_idx != -1:
    print(f"panel-edit starts at line {start_idx+1}")
    if end_idx == -1:
        end_idx = start_idx + 300
    print(f"Printing from line {start_idx+1} to {end_idx}:")
    for i in range(start_idx, min(end_idx, len(lines))):
        print(f"{i+1}: {lines[i].rstrip()}")
else:
    print("Could not find panel-edit in admin.php")
