import re

with open('assets/css/style.css', 'r', encoding='utf-8') as f:
    content = f.read()

default_colors = {
    'primary': '#1e3d2f',
    'secondary': '#ff7a00',
    'accent': '#0077b6'
}

for name, hex_val in default_colors.items():
    matches = [m.start() for m in re.finditer(re.escape(hex_val), content, re.IGNORECASE)]
    print(f"Color '{name}' ({hex_val}) matches count: {len(matches)}")
    if matches:
        for m in matches[:5]:
            line_num = content.count('\n', 0, m) + 1
            start = max(0, m - 40)
            end = min(len(content), m + 40)
            print(f"  Line {line_num}: ... {content[start:end].strip()} ...")
