with open('admin.php', 'r', encoding='utf-8') as f:
    content = f.read()

import re
print("Searching for <main>:")
for match in re.finditer(r'<main[^>]*>', content, re.IGNORECASE):
    print(match.group(0), "at index", match.start())
print("Searching for body style attributes or classes:")
for match in re.finditer(r'<body[^>]*>', content, re.IGNORECASE):
    print(match.group(0))
