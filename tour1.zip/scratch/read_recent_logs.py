import json

log_path = r"C:\Users\SGHACKER\.gemini\antigravity\brain\9c814c8b-ab84-4384-a6ff-3cf157a08265\.system_generated\logs\transcript.jsonl"

with open(log_path, 'r', encoding='utf-8') as f:
    for line_idx, line in enumerate(f):
        try:
            obj = json.loads(line)
            step_idx = obj.get('step_index', line_idx)
            if step_idx == 828:
                tool_calls = obj.get('tool_calls', [])
                for t in tool_calls:
                    args = t.get('args', {})
                    chunks = args.get('ReplacementChunks', [])
                    print(f"Total chunks in Step 828: {len(chunks)}")
                    for c_idx, c in enumerate(chunks):
                        print(f"--- Chunk {c_idx+1} (Lines {c.get('StartLine')}-{c.get('EndLine')}) ---")
                        print("Target:")
                        print(c.get('TargetContent'))
                        print("Replacement:")
                        print(c.get('ReplacementContent'))
                        print("=" * 60)
        except Exception as e:
            pass
