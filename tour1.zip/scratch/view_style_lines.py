with open('assets/css/style.css', 'r', encoding='utf-8') as f:
    lines = f.readlines()

for i in range(459, min(485, len(lines))):
    print(f"Line {i+1}: {lines[i].rstrip()}")
