with open('admin.php', 'r', encoding='utf-8') as f:
    for idx, line in enumerate(f):
        if 'header.php' in line or 'footer.php' in line or 'include' in line or 'require' in line:
            print(f"Line {idx+1}: {line.strip()}")
