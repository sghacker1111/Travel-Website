with open('assets/css/style.css', 'r', encoding='utf-8') as f:
    lines = f.readlines()

print(f"Total lines in style.css: {len(lines)}")

# Search for overflow, height, body, html
keywords = ['overflow', 'height', 'body', 'html']
for idx, line in enumerate(lines):
    for kw in keywords:
        if kw.lower() in line.lower():
            print(f"Line {idx+1}: {line.strip()[:100]}")
            break
