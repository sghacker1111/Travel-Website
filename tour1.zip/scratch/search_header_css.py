with open('assets/css/style.css', 'r', encoding='utf-8') as f:
    lines = f.readlines()

for idx, line in enumerate(lines):
    if 'header' in line:
        # print line and surrounding lines
        print(f"Line {idx+1}: {line.strip()}")
        start = max(0, idx - 2)
        end = min(len(lines), idx + 5)
        for i in range(start, end):
            print(f"  {i+1}: {lines[i].rstrip()}")
        print("-" * 50)
