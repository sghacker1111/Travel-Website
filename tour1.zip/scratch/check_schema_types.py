import json

with open('data/packages.json', 'r', encoding='utf-8') as f:
    packages = json.load(f)

print(f"Total packages: {len(packages)}")

field_types = {
    'highlights': set(),
    'costIncludes': set(),
    'costExcludes': set(),
    'requiredPermits': set(),
    'itinerary': set()
}

issues = []

for idx, p in enumerate(packages):
    for field in field_types.keys():
        val = p.get(field)
        field_types[field].add(type(val).__name__)
        
        # Detailed checks
        if field == 'itinerary':
            if not isinstance(val, list):
                issues.append(f"Package {idx} ({p.get('title')}): itinerary is {type(val).__name__}")
            else:
                for day_idx, day in enumerate(val):
                    if not isinstance(day, dict):
                        issues.append(f"Package {idx} ({p.get('title')}): day {day_idx} is not a dict")
                    else:
                        for k in ['day', 'title', 'desc', 'accommodation', 'meals']:
                            if k not in day:
                                issues.append(f"Package {idx} ({p.get('title')}): day {day_idx} missing key '{k}'")

print("Field types found in packages.json:")
for field, types in field_types.items():
    print(f"  {field}: {list(types)}")

if issues:
    print(f"Schema issues found: {len(issues)}")
    for issue in issues[:10]:
        print(f"  - {issue}")
else:
    print("No itinerary or basic structure schema issues found!")
