import requests
import json
import re

base_url = 'http://127.0.0.1:8080'

try:
    packages = json.load(open('data/packages.json', encoding='utf-8'))
except Exception as e:
    print(f"Failed to load packages.json: {e}")
    exit(1)

urls_to_test = [
    '/',
    '/blog',
    '/contact',
    '/about',
    '/trekking',
    '/tour',
    '/peak-climbing',
    '/sitemap.xml'
]

# Add a few representative package pages
for pkg in packages[:15]:
    # Determine correct category link (trekking, tour, peak-climbing)
    category = pkg.get('category', 'trekking').lower()
    urls_to_test.append(f"/{category}/{pkg['slug']}")

print(f"Testing {len(urls_to_test)} URLs for PHP errors/warnings...")

error_patterns = [
    r'(?i)fatal error',
    r'(?i)parse error',
    r'(?i)warning:',
    r'(?i)notice:',
    r'(?i)deprecated:',
    r'(?i)stack trace',
    r'(?i)uncaught exception'
]

has_errors = False

for url in urls_to_test:
    full_url = base_url + url
    try:
        r = requests.get(full_url, timeout=5)
        text = r.text
        status = r.status_code
        
        # Check status code
        if status != 200:
            print(f"[-] HTTP {status} on {url}")
            has_errors = True
            
        # Check body for PHP error signatures
        found_errs = []
        for pat in error_patterns:
            matches = re.findall(pat, text)
            if matches:
                found_errs.append(matches[0])
                
        if found_errs:
            print(f"[-] PHP Error signature {found_errs} detected in {url}!")
            # Print a snippet around the error
            for err in found_errs:
                idx = text.lower().find(err.lower())
                start = max(0, idx - 100)
                end = min(len(text), idx + 200)
                print(f"    Snippet: {text[start:end]}\n")
            has_errors = True
        else:
            if status == 200:
                print(f"[+] URL {url} loaded clean (200 OK)")
    except Exception as e:
        print(f"[-] Connection failed for {url}: {e}")
        has_errors = True

if not has_errors:
    print("[+] All tested URLs loaded cleanly without PHP errors/warnings!")
else:
    print("[-] Some errors or warnings were found!")
