with open('assets/css/style.css', 'r', encoding='utf-8') as f:
    lines = f.readlines()

for idx, line in enumerate(lines):
    if 'label' in line.lower():
        print(f"Line {idx+1}: {line.strip()}")
        start = max(0, idx - 2)
        end = min(len(lines), idx + 8)
        for i in range(start, end):
            print(f"  {i+1}: {lines[i].rstrip()}")
        print("-" * 50)
