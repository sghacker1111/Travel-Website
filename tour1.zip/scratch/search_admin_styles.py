import re

with open('admin.php', 'r', encoding='utf-8') as f:
    content = f.read()

# Let's find <style> tags or inline style blocks and print them fully
matches = re.finditer(r'<style>(.*?)</style>', content, re.DOTALL)
for idx, match in enumerate(matches):
    print(f"Style Block {idx+1}:")
    print(match.group(1))
    print("=" * 60)
