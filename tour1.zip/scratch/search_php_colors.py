import os
import re

default_colors = ['#1e3d2f', '#ff7a00', '#0077b6', '#0077b8']

# Walk through directories
for root, dirs, files in os.walk('.'):
    # Skip assets, data, and .git/scratch
    if any(p in root for p in ['assets', 'data', '.git', 'scratch']):
        continue
    for file in files:
        if file.endswith('.php'):
            filepath = os.path.join(root, file)
            with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            for color in default_colors:
                matches = [m.start() for m in re.finditer(re.escape(color), content, re.IGNORECASE)]
                if matches:
                    print(f"File '{filepath}' has hardcoded color '{color}' at:")
                    for m in matches:
                        line_num = content.count('\n', 0, m) + 1
                        start = max(0, m - 40)
                        end = min(len(content), m + 40)
                        print(f"  Line {line_num}: ... {content[start:end].strip()} ...")
