import os

php_files = []
for root, dirs, files in os.walk('.'):
    if any(p in root for p in ['assets', 'data', '.git', 'scratch']):
        continue
    for file in files:
        if file.endswith('.php'):
            php_files.append(os.path.join(root, file))

for filepath in php_files:
    with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
        content = f.read()
    if 'acc-item' in content or 'acc-header' in content:
        print(f"File '{filepath}' uses standard accordion classes.")
