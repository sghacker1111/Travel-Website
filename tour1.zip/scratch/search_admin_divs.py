with open('admin.php', 'r', encoding='utf-8') as f:
    content = f.read()

import re
# Find all divs with inline styling
divs = re.finditer(r'<div\s+([^>]*style=[^>]+)>', content)
print("Divs with inline styles:")
for idx, div in enumerate(divs):
    tag = div.group(0)
    # Check if height, overflow, max-width, width or scroll are in tag
    if any(k in tag for k in ['height', 'overflow', 'scroll', 'position', 'max-height', 'vh']):
        print(f"Line approx {content.count('\n', 0, div.start()) + 1}: {tag}")
