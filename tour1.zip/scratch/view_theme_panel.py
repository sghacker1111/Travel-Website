with open('admin.php', 'r', encoding='utf-8') as f:
    lines = f.readlines()

start_idx = -1
end_idx = -1
for idx, line in enumerate(lines):
    if 'id="panel-theme"' in line:
        start_idx = idx
    if start_idx != -1 and '<!-- Tab' in line[idx+1:] or 'id="panel-' in line:
        if start_idx != -1 and idx > start_idx:
            end_idx = idx
            break

if start_idx != -1:
    print(f"panel-theme starts at line {start_idx+1}")
    if end_idx == -1:
        end_idx = start_idx + 100
    print(f"Printing from line {start_idx+1} to {end_idx}:")
    for i in range(start_idx, min(end_idx, len(lines))):
        print(f"{i+1}: {lines[i].rstrip()}")
else:
    print("Could not find panel-theme in admin.php")
