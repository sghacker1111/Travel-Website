import requests
import json
import re

packages = json.load(open('data/packages.json', encoding='utf-8'))
base_url = 'http://127.0.0.1:8080'
error_patterns = [
    r'(?i)fatal error',
    r'(?i)parse error',
    r'(?i)warning:',
    r'(?i)notice:',
    r'(?i)deprecated:',
    r'(?i)stack trace',
    r'(?i)uncaught exception'
]
has_errors = False

for index, pkg in enumerate(packages):
    category = pkg.get('category', 'trekking').lower()
    url = f"/{category}/{pkg['slug']}"
    try:
        r = requests.get(base_url + url)
        if r.status_code != 200:
            print(f"[-] HTTP {r.status_code} on {url}")
            has_errors = True
        
        found = []
        for pat in error_patterns:
            if re.search(pat, r.text):
                found.append(pat)
        
        if found:
            print(f"[-] PHP Error signatures {found} detected in {url}!")
            has_errors = True
    except Exception as e:
        print(f"[-] Failed to fetch {url}: {e}")
        has_errors = True

if not has_errors:
    print(f"[+] Successfully verified all {len(packages)} packages without errors!")
else:
    print("[-] Errors or warnings were found in some packages!")
