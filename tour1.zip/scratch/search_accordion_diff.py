import json

log_path = r"C:\Users\SGHACKER\.gemini\antigravity\brain\9c814c8b-ab84-4384-a6ff-3cf157a08265\.system_generated\logs\transcript.jsonl"

with open(log_path, 'r', encoding='utf-8') as f:
    for line_idx, line in enumerate(f):
        try:
            obj = json.loads(line)
            step_idx = obj.get('step_index', line_idx)
            if step_idx == 828:
                tool_calls = obj.get('tool_calls', [])
                for t in tool_calls:
                    args = t.get('args', {})
                    chunks_str = args.get('ReplacementChunks', '')
                    try:
                        chunks = json.loads(chunks_str, strict=False)
                        print(f"Parsed {len(chunks)} chunks successfully!")
                        for c_idx, c in enumerate(chunks):
                            target = c.get('TargetContent', '')
                            replacement = c.get('ReplacementContent', '')
                            print(f"--- Chunk {c_idx+1} ---")
                            print("TARGET:")
                            print(target)
                            print("REPLACEMENT:")
                            print(replacement)
                            print("=" * 60)
                    except Exception as e:
                        print("Failed to parse chunks_str as JSON:", e)
        except Exception as e:
            pass
