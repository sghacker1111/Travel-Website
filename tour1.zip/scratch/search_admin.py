with open('admin.php', 'r', encoding='utf-8') as f:
    lines = f.readlines()

print(f"Total lines in admin.php: {len(lines)}")

# Search for profile, password, edit settings, scroll
keywords = ['profile', 'password', 'scroll', 'username']
for idx, line in enumerate(lines):
    for kw in keywords:
        if kw.lower() in line.lower():
            print(f"Line {idx+1}: {line.strip()[:100]}")
            break
