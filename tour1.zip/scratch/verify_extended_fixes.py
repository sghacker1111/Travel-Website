import os
import json
import urllib.request
import urllib.parse

BASE_URL = "http://127.0.0.1:8080"

def test_theme_config():
    print("--- Testing Theme Customizer Configurations ---")
    theme_path = "data/theme.json"
    if os.path.exists(theme_path):
        with open(theme_path, "r", encoding="utf-8") as f:
            theme = json.load(f)
        print("Success: theme.json exists and is valid JSON.")
        print(f"Primary Color: {theme.get('primary')}")
        print(f"Logo Font Size: {theme.get('logo_font_size')}")
        print(f"Trekking Alignment: {theme.get('trek_align')}")
    else:
        print("Error: theme.json does not exist.")

def test_routes():
    print("\n--- Testing Route Accessibilities ---")
    routes = ["/destination", "/contact", "/trekking", "/tour", "/peak-climbing"]
    for route in routes:
        url = BASE_URL + route
        try:
            req = urllib.request.Request(url, method="GET")
            with urllib.request.urlopen(req) as resp:
                status = resp.status
                content = resp.read().decode("utf-8")
                if "404" in content or status != 200:
                    print(f"Route {route}: Failed (HTTP {status} or page error)")
                else:
                    print(f"Route {route}: Success (HTTP {status})")
        except Exception as e:
            print(f"Route {route}: Failed with exception: {e}")

def test_chatbot_api():
    print("\n--- Testing Chatbot API (/ai-chat.php) ---")
    url = BASE_URL + "/ai-chat.php"
    data = urllib.parse.urlencode({"query": "Tell me about Everest trekking"}).encode("utf-8")
    try:
        req = urllib.request.Request(url, data=data, method="POST")
        req.add_header("Content-Type", "application/x-www-form-urlencoded")
        with urllib.request.urlopen(req) as resp:
            res_data = json.loads(resp.read().decode("utf-8"))
            print("Chatbot Response JSON:")
            print(json.dumps(res_data, indent=2))
            if "reply" in res_data:
                print("Success: Chatbot answered successfully.")
            else:
                print("Error: Chatbot response format invalid.")
    except Exception as e:
        print(f"Chatbot API failed with exception: {e}")

def test_password_recovery_otp():
    print("\n--- Testing Forgot Password & OTP Recovery flow ---")
    otp_log = "data/recovery_otp.txt"
    if os.path.exists(otp_log):
        os.remove(otp_log)
        
    # Step 1: Send OTP POST request
    url = BASE_URL + "/admin.php?action=forgot_password"
    data = urllib.parse.urlencode({"action_send_otp": "1"}).encode("utf-8")
    try:
        req = urllib.request.Request(url, data=data, method="POST")
        req.add_header("Content-Type", "application/x-www-form-urlencoded")
        
        # Use HTTPCookieProcessor to handle session cookies
        cookie_processor = urllib.request.HTTPCookieProcessor()
        opener = urllib.request.build_opener(cookie_processor)
        
        with opener.open(req) as resp:
            html = resp.read().decode("utf-8")
            if "Verify OTP" in html or "verification code" in html:
                print("Step 1 Success: Transitioned to Verify OTP state.")
            else:
                print("Step 1 Warning: Expected to see OTP input form/message.")
                
        # Step 2: Read OTP from recovery_otp.txt
        if os.path.exists(otp_log):
            with open(otp_log, "r") as f:
                log_content = f.read()
            print(f"Logged OTP Content: {log_content.strip()}")
            import re
            otp_match = re.search(r'OTP:\s*(\d{6})', log_content)
            if otp_match:
                otp_code = otp_match.group(1)
                print(f"Extracted OTP: {otp_code}")
                
                # Step 3: Verify OTP code
                verify_data = urllib.parse.urlencode({"otp": otp_code, "action_verify_otp": "1"}).encode("utf-8")
                verify_req = urllib.request.Request(url, data=verify_data, method="POST")
                verify_req.add_header("Content-Type", "application/x-www-form-urlencoded")
                with opener.open(verify_req) as verify_resp:
                    verify_html = verify_resp.read().decode("utf-8")
                    if "Reset Pass" in verify_html or "new password" in verify_html:
                        print("Step 3 Success: OTP verified successfully. Reset form visible.")
                    else:
                        print("Step 3 Warning: Reset Pass form not found in html.")
            else:
                print("Error: Could not parse 6-digit OTP from recovery_otp.txt")
        else:
            print("Error: recovery_otp.txt was not created in data/ directory.")
    except Exception as e:
        print(f"OTP Flow failed with exception: {e}")

if __name__ == "__main__":
    test_theme_config()
    test_routes()
    test_chatbot_api()
    test_password_recovery_otp()
