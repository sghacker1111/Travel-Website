import json

log_path = r"C:\Users\SGHACKER\.gemini\antigravity\brain\9c814c8b-ab84-4384-a6ff-3cf157a08265\.system_generated\logs\transcript.jsonl"

with open(log_path, 'r', encoding='utf-8') as f:
    for line_idx, line in enumerate(f):
        try:
            obj = json.loads(line)
            step_idx = obj.get('step_index', line_idx)
            if 783 <= step_idx <= 828:
                if obj.get('source') == 'MODEL' and obj.get('type') == 'PLANNER_RESPONSE':
                    print(f"=== Step {step_idx} ===")
                    print(obj.get('content')[:800])
                    print("-" * 60)
        except Exception as e:
            pass
