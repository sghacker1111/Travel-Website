with open('admin.php', 'r', encoding='utf-8') as f:
    content = f.read()

import re
print("Matches for footer in admin.php:")
for match in re.finditer(r'(?i)footer', content):
    start = max(0, match.start() - 30)
    end = min(len(content), match.end() + 30)
    print(f"  ... {content[start:end].strip()} ...")
