with open('assets/css/style.css', 'r', encoding='utf-8') as f:
    lines = f.readlines()

for i in range(415, min(435, len(lines))):
    print(f"Line {i+1}: {lines[i].rstrip()}")
