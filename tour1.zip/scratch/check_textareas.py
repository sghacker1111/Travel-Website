with open('admin.php', 'r', encoding='utf-8') as f:
    content = f.read()

for textarea_id in ['edit-overview', 'edit-highlights', 'edit-costIncludes', 'edit-costExcludes', 'edit-requiredPermits', 'blog-content', 'page-content']:
    present = f'id="{textarea_id}"' in content or f"id='{textarea_id}'" in content
    print(f"Textarea '{textarea_id}': present={present}")
