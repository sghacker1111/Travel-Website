import json
import re
import os
import random

input_titles = [
    "14 Day Annapurna Base Camp Trek",
    "ABC Trek from Pokhara - 6 Days",
    "Mardi Himal Trek - 9 Days",
    "Annapurna North Base Camp Trek - 12 Days",
    "3 Days Poon Hill Trek from Pokhara",
    "Annapurna Circuit Trek - 12 Days",
    "Ghorepani Poonhill Trek - 8 Days",
    "Short ABC Trek - 9 Days",
    "2 Days Poon Hill Trek",
    "Poon Hill Mardi Himal Trek - 12 Days",
    "ABC Trek with Poon hill and Mardi Himal - 17 Days",
    "Annapurna Base Camp Trek with Helicopter Return - 8 Days",
    "Annapurna Tilicho Lake Trek - 16 Days",
    "Khopra Danda Trek with Khayer Lake - 12 Days",
    "Nar Phu Valley Trek with Kang La and Thorong La Pass- 17 Days",
    "Nar Phu Trek with Tilicho Lake - 21 Days",
    "Kapuche Lake with Kori Himal Trek - 11 Days",
    "Kori Himal Trek - 10 Days",
    "Sikles Kapuche Lake Trek - 8 Days",
    "Mohare Danda Trek - 9 Days",
    "Mohare Danda Khopra Trek - 14 Days",
    "Everest Base Camp Trek - 14 Days",
    "Sleep at Base Camp on Everest Trek - 15 Days",
    "Luxury Everest Heli Trek - 6 Days",
    "EBC Trek via Gokyo with Helicopter Return - 15 Days",
    "EBC Trek Helicopter Return from Pheriche - 11 Days",
    "Three High Passes Trek by Road - 19 Days",
    "11 Days Super Luxury Everest Base Camp Trek",
    "Everest Three Passes Trek - 18 Days",
    "Budget Everest Base Camp Trek - 12 Days",
    "Everest High Passes Trek Clockwise - 18 Days",
    "Gokyo Valley Circuit Trek - 13 Days",
    "Everest View Trek - 9 Days",
    "Everest Trek Cost for Indians - 14 Days",
    "Everest Gokyo Trek via Salleri - 20 Days",
    "Rapid (Short) Everest Base Camp Trek - 9 Days",
    "EBC Trek via Gokyo Cho La Pass - 17 Days",
    "Everest Base Camp Trek Helicopter Return to Kathmandu - 10 Days",
    "Gokyo Chola Pass Trekking via EBC - 17 Days",
    "Everest Base Camp Trek Heli Out to Lukla - 12 Days",
    "Pikey Peak Trek - 10 Days",
    "Everest Base Camp Trek by Road - 16 Days",
    "Langtang Valley Trek - 10 Days",
    "Ama Yangri Trek - 3 Days",
    "Langtang Gosaikunda Lake Trek - 15 Days",
    "Gosaikunda Lake Trek - 7 Days",
    "Tamang Heritage Trail Trek - 10 Days",
    "Helambu Circuit Trek - 8 Days",
    "Langtang Ganja La Pass Trek - 14 Days",
    "Manaslu Circuit Trek - 14 Days",
    "Manaslu Luxury Trek - 17 Days",
    "Lower Manaslu Eco Trail Trek - 12 Days",
    "Short Manaslu Trek - 11 Days",
    "Manaslu Tsum Valley Trek - 18 Days",
    "Manaslu Annapurna Circuit Trek - 23 Days",
    "Tsum Valley Trek - 15 Days",
    "Annapurna Seven Passes Trek - 23 Days",
    "Mustang Tiji Festival Tour - 14 Days",
    "Upper Mustang Trek - 17 Days",
    "Makalu Base Camp Trek - 19 Days",
    "Kanchenjunga North Base Camp Trek - 20 Days",
    "Kanchenjunga South Base Camp Trek - 13 Days",
    "Kanchenjunga Circuit Trek - 22 Days",
    "Dhampus Sarangkot Trek - 3 Days",
    "Chisapani Nagarkot Trek - 3 Days",
    "Rara Lake Yoga Trek - 12 Days",
    "Everest Monastery Yoga Trek - 10 Days",
    "Upper Dolpo Trek - 28 Days",
    "Lower Dolpo Trek - 18 Days"
]

def parse_package(raw_title):
    # Extract duration
    duration = 14
    match = re.search(r'(\d+)\s*Day', raw_title, re.IGNORECASE)
    if match:
        duration = int(match.group(1))
    
    # Clean title
    clean_title = re.sub(r'[-–]\s*\d+\s*Days?.*', '', raw_title, flags=re.IGNORECASE).strip()
    clean_title = re.sub(r'^\d+\s*Days?\s+', '', clean_title, flags=re.IGNORECASE).strip()
    clean_title = clean_title.replace("Trek Cost for Indians", "Trek Package")
    clean_title = clean_title.replace("Sleep at Base Camp on Everest Trek", "Everest Base Camp Overnight Trek")
    
    # Base slug
    slug = re.sub(r'[^a-z0-9]+', '-', clean_title.lower()).strip('-')
    
    # Region categorization
    region = "Other"
    image = "assets/images/packages/hero_home.jpg"
    cat = "trekking"
    
    t_low = clean_title.lower()
    if 'everest' in t_low or 'ebc' in t_low or 'gokyo' in t_low or 'lukla' in t_low:
        region = "Everest Region"
        image = "assets/images/packages/hero_everest.jpg"
    elif 'annapurna' in t_low or 'abc' in t_low or 'poon' in t_low or 'mardi' in t_low or 'tilicho' in t_low:
        region = "Annapurna Region"
        image = "assets/images/packages/hero_annapurna.jpg"
    elif 'langtang' in t_low or 'gosaikunda' in t_low or 'tamang' in t_low or 'helambu' in t_low:
        region = "Langtang Region"
        image = "assets/images/packages/hero_langtang.jpg"
    elif 'manaslu' in t_low or 'tsum' in t_low:
        region = "Manaslu Region"
        image = "assets/images/packages/hero_manaslu.jpg"
    elif 'mustang' in t_low:
        region = "Mustang Region"
        image = "assets/images/packages/hero_mustang.jpg"
    elif 'makalu' in t_low:
        region = "Makalu Region"
    elif 'kanchenjunga' in t_low:
        region = "Kanchenjunga Region"
    elif 'dolpo' in t_low:
        region = "Dolpo Region"
    
    if 'yoga' in t_low:
        region = "Yoga & Wellness"
    
    # Generate Itinerary
    itinerary = []
    itinerary.append({
        "day": 1,
        "title": "Arrival in Kathmandu and transfer to hotel",
        "desc": "Welcome to Kathmandu. Our representative will receive you at Tribhuvan International Airport and transfer you to your hotel. You will have a brief trip orientation.",
        "location": "Kathmandu",
        "accommodation": "3-Star Hotel",
        "meals": "None"
    })
    
    for i in range(2, duration):
        itinerary.append({
            "day": i,
            "title": f"Trekking in the {region}",
            "desc": "Today we will trek along beautiful trails, cross suspension bridges, and enjoy panoramic views of the high Himalayas. We will stop for lunch at a scenic viewpoint and continue to our teahouse.",
            "accommodation": "Teahouse Lodge",
            "meals": "Breakfast, Lunch, Dinner"
        })
    
    if duration > 1:
        itinerary.append({
            "day": duration,
            "title": "Departure or Onward Journey",
            "desc": "After breakfast, you will be transferred to the airport for your final departure. We hope you had a wonderful adventure with Top Mountain Treks.",
            "location": "Kathmandu",
            "accommodation": "None",
            "meals": "Breakfast"
        })
        
    return {
        "id": slug,
        "slug": slug,
        "category": cat,
        "title": clean_title,
        "region": region,
        "duration": duration,
        "priceUSD": max(300, duration * 95),
        "priceNPR": max(300, duration * 95) * 133,
        "priceNote": "Price is per person based on group booking",
        "difficulty": "Moderate to Challenging",
        "maxAltitude": "3,000m - 5,500m (Varies by trail)",
        "bestSeason": "Spring (Mar-May) & Autumn (Sep-Nov)",
        "startPoint": "Kathmandu",
        "endPoint": "Kathmandu",
        "accommodation": "Hotel in Kathmandu and teahouses on trek",
        "meals": "Full board on trek; breakfast in Kathmandu",
        "groupSize": "2 to 14 people",
        "overview": f"The {clean_title} is one of the most spectacular journeys in the {region}. This highly-rated package combines authentic cultural experiences with unparalleled Himalayan vistas. Designed by experts, the {duration}-day itinerary allows sufficient acclimatization while guaranteeing unforgettable views.",
        "highlights": [
            f"Breathtaking views of the {region} peaks",
            "Immersive cultural encounters with local mountain communities",
            "Guided by certified, English-speaking Sherpa guides",
            "All-inclusive lodging and meals during the trek",
            "Flexible pace to ensure proper acclimatization"
        ],
        "itinerary": itinerary,
        "costIncludes": [
            "Airport pick-up and drop-off",
            "All necessary trekking permits (TIMS, National Park)",
            "Experienced English-speaking trekking guide",
            "Porter service (1 porter for 2 trekkers)",
            "Accommodation in standard teahouses during the trek"
        ],
        "costExcludes": [
            "International flights and Nepal entry visa fee",
            "Personal travel insurance (mandatory)",
            "Lunch and dinner in Kathmandu",
            "Personal expenses (Wi-Fi, hot showers, drinks)",
            "Tips for guides and porters"
        ],
        "requiredPermits": ["TIMS Card", "National Park / Conservation Area Entry Permit"],
        "faqs": [
            {"q": "How physically fit do I need to be?", "a": "You should be able to walk 5-7 hours a day. Previous trekking experience is beneficial but not strictly necessary for most moderate trails."},
            {"q": "Is travel insurance required?", "a": "Yes, mandatory travel insurance covering high-altitude helicopter rescue up to 6,000m is required."}
        ],
        "gallery": [],
        "image": image,
        "reviews": []
    }

def main():
    pkg_path = "data/packages.json"
    if os.path.exists(pkg_path):
        with open(pkg_path, "r", encoding="utf-8") as f:
            existing = json.load(f)
    else:
        existing = []
        
    existing_slugs = {p['slug'] for p in existing}
    
    new_packages = []
    for title in input_titles:
        pkg = parse_package(title)
        
        # Ensure unique slug
        base_slug = pkg['slug']
        counter = 1
        while pkg['slug'] in existing_slugs:
            pkg['slug'] = f"{base_slug}-{counter}"
            pkg['id'] = pkg['slug']
            counter += 1
            
        existing_slugs.add(pkg['slug'])
        new_packages.append(pkg)
        
    existing.extend(new_packages)
    
    with open(pkg_path, "w", encoding="utf-8") as f:
        json.dump(existing, f, indent=4)
        
    print(f"Successfully added {len(new_packages)} packages!")

if __name__ == "__main__":
    main()
